/*
Note that if you do not have SQL Server to try this on, you can go to the W3schools website and use the SQL try-it editor.
You'll need to be using a browser with WebSQL support - try it with Chrome!
https://www.w3schools.com/sql/trysql.asp?filename=trysql_op_in
You can build this schema in a DB through this site by pasting in one command at a time and executing it.
Note that this instance of SQL is cases sensitive.

Please confirm that you can run these commands one at a time and then get results for the select statement at the end.
*/

create table department(department_id int NOT NULL, department_name varchar(100) NOT NULL, over_budget tinyint);
create table employee(employee_id int NOT NULL, last_name varchar(100) NOT NULL, first_name varchar(100) NOT NULL, department_id int, salary numeric(10,2));
create table task(task_id int NOT NULL, employee_id int, task_description varchar(256));
insert into department values(1,'Accounting',1),(2,'Sales',0),(3,'Research',0),(4,'Marketing',1);
insert into employee values(1,'Jackson','Bo',1,30000),(2,'Jordan','Michael',2,25000),(3,'Mattingly','Don',4,27000),(4,'Gretzky','Wayne',4,26500),(5,'Montana','Joe',3,33000),(6,'Tarkenton','Fran',2,24000),(7,'Comaneci','Nadia',1,31000),(8,'Solo','Hope',NULL,26000);
insert into task values(1,4,'Make Commercial'),(2,6,'Make Commercial'),(3,1,'Make Commercial'),(4,2,'Make Commercial'),(5,5,'Make Commercial'),(6,8,'Make Commercial'),(7,3,'Make Commercial'),(8,7,'Make Commercial'),(9,5,'Make Commercial'),(10,4,'Make Commercial');
select * from department;

