// If you have VSCode and node installed...
// Open a new terminal window (View -> Terminal or Terminal -> New Terminal)
// Type: node js_questions.js
// It should print "hello candidate!" to the terminal.
var msg = "hello candidate!";
console.log(msg);
