/*
    In Visual Studio Code, open a new terminal window (View -> Terminal or Terminal -> New Terminal)
    Execute: dotnet new console
    This should setup a new .NET project with a Program.cs file.
    Now replace the content of the Program.cs file with the content of this file.  Comment out C#_questions.cs.  Save both.
        One way or another, there can be only one Main entry point.
    Run it by executing this in the terminal: dotnet run
    You should see "hello candidate" in the output window.
*/

using System;

namespace DevTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello candidate!");
        }
    }

